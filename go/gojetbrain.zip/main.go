package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"strings"
	"time"
)

type Response struct {
	ListaDezenas []string `json:"listaDezenas"`
	Numero       int      `json:"numero"`
}

var filePath = "c:\\projects\\gojetbrain\\loto.txt"

func main() {
	println("ok")
	//getResult("3287")
	getResult("3288")
	checkWins()
}

func checkWins() {
	var magicNumbers []string
	//magicNumbers = []string{"01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15"} // sequencia
	//magicNumbers = []string{"02", "03", "04", "05", "07", "11", "14", "16", "19", "20", "21", "24", "25", "15", "06"} // 06 15 23
	//magicNumbers = []string{"08", "11", "12", "13", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25"} ??
	// 18, 19, 20, 21, 22, 23, 24, 25
	//magicNumbers = []string{"16", "17", "18", "19", "20", "21", "15", "23", "14", "25"}
	magicNumbers = []string{"02", "04", "05", "06", "07", "08", "09", "11", "12", "14", "16", "17", "18", "19", "22"} // meu?
	//magicNumbers = []string{"01", "05", "10", "11", "13", "12", "14", "15", "16", "17", "18", "19", "20", "21", "25"} // prox
	//magicNumbers = []string{"09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "20", "22", "23", "24", "25"} // um bom 1?
	//magicNumbers = []string{"10", "25", "11", "13", "24", "14", "04", "12", "03", "05", "01", "02", "09", "22", "21"} // um bom 2?
	//magicNumbers = []string{"01", "05", "07", "10", "11", "12", "14", "15", "16", "17", "18", "19", "20", "21", "25"} // great
	//magicNumbers = []string{"02", "03", "04", "06", "07", "08", "13", "14", "16", "17", "18", "21", "22", "24", "25"} //deu 3x 14pt
	//magicNumbers = []string{"02", "05", "07", "08", "10", "11", "13", "14", "15", "19", "20", "21", "23", "24", "25"} //deu 3x 14pt
	//magicNumbers = []string{"02", "03", "08", "09", "11", "12", "13", "14", "15", "17", "18", "19", "20", "22", "23"} //deu 3x 14pt

	if len(magicNumbers) != 15 {
		//println("numeros invalidos")
		//return
	}

	/*
		file, _ := os.Open(filePath)
		scanner := bufio.NewScanner(file)
		scanner.Split(bufio.ScanLines)

		for scanner.Scan() {
			text1 := scanner.Text()
			text2 := strings.Split(text1, "| ")

			//xxx := strings.Replace(text2[1], "01, ", "", -1)
			xxx := text2[1]
			//println(xxx)      //text2[1][0:55])
			//println(len(xxx)) //text2[1][0:55])

			//if len(xxx) == 55 {
			println(xxx)
			loadFileData(strings.Split(xxx, ","))
			//}
		}
		_ = file.Close()
		return
	*/
	loadFileData(magicNumbers)
}

func getResult(concourse string) {
	/*
		for i := 3242; i > 3000; i-- {
			println(i)

			data := loadConcourseData(strconv.Itoa(i))
			if data == nil {
				return
			}

			writeDataOnFile(*data)
			time.Sleep(time.Second * 1)
		}
	*/

	data := loadConcourseData(concourse)
	if data == nil {
		return
	}

	writeDataOnFile(*data)
}

func loadFileData(magicNumbers []string) {
	file, err := os.Open(filePath)
	check(err, "Error to open file")

	scanner := bufio.NewScanner(file)
	scanner.Split(bufio.ScanLines)
	var textLines []string

	totalLines := 0
	for scanner.Scan() {
		textLines = append(textLines, scanner.Text())
		totalLines++
	}
	fmt.Printf("Jogos %d \n", totalLines)
	premios01 := 0

	premios09 := 0
	premios10 := 0

	premios11 := 0
	premios12 := 0
	premios13 := 0
	premios14 := 0
	premios15 := 0

	number_01 := 0
	number_02 := 0
	number_03 := 0
	number_04 := 0
	number_05 := 0
	number_06 := 0
	number_07 := 0
	number_08 := 0
	number_09 := 0
	number_10 := 0
	number_11 := 0
	number_12 := 0
	number_13 := 0
	number_14 := 0
	number_15 := 0
	number_16 := 0
	number_17 := 0
	number_18 := 0
	number_19 := 0
	number_20 := 0
	number_21 := 0
	number_22 := 0
	number_23 := 0
	number_24 := 0
	number_25 := 0

	// 1 - 1954
	// 1 - 1947

	for _, eachLine := range textLines {
		if len(eachLine) < 10 {
			continue
		}
		data := strings.Split(eachLine, "|")
		//items := strings.Split(data[1], ", ")

		total := 0
		for _, val := range magicNumbers {
			if strings.Contains(data[1], val) {
				total++
			}
		}

		for _, val := range strings.Split(data[1], ",") {
			switch strings.TrimSpace(val) {
			case "01":
				number_01++
			case "02":
				number_02++
			case "03":
				number_03++
			case "04":
				number_04++
			case "05":
				number_05++
			case "06":
				number_06++
			case "07":
				number_07++
			case "08":
				number_08++
			case "09":
				number_09++
			case "10":
				number_10++
			case "11":
				number_11++
			case "12":
				number_12++
			case "13":
				number_13++
			case "14":
				number_14++
			case "15":
				number_15++
			case "16":
				number_16++
			case "17":
				number_17++
			case "18":
				number_18++
			case "19":
				number_19++
			case "20":
				number_20++
			case "21":
				number_21++
			case "22":
				number_22++
			case "23":
				number_23++
			case "24":
				number_24++
			case "25":
				number_25++
			}
		}

		if total > 10 {
			fmt.Printf("%v %v \n", data[0], total)
		}
		switch total {
		case 2:
			premios01++

		case 9:
			premios09++
		case 10:
			premios10++
		//
		case 11:
			premios11++
		case 12:
			premios12++
		case 13:
			premios13++
		case 14:
			premios14++
		case 15:
			premios15++
		default:
			break
		}

		//if total == 14 {
		//	fmt.Printf("%v - %v \n", data[0], data[1])
		//}
		//fmt.Println(eachLine)
	}

	fmt.Print("\n\n")
	fmt.Printf("JOGO: %v\n\n", magicNumbers)

	valor11 := float32(premios11) * 6.0
	valor12 := float32(premios12) * 12.0
	valor13 := float32(premios13) * 30.0
	valor14 := float32(premios14) * 800.0
	valor15 := float32(premios15) * 300_000.0
	gastou := float32(totalLines) * 3.0
	premio := valor11 + valor12 + valor13 + valor14 + valor15

	//fmt.Printf("%v", premios01)
	fmt.Printf("09 [%4d] \n", premios09)
	fmt.Printf("10 [%4d] \n", premios10)

	fmt.Printf("premios11 [%4d] valor +- [%10.2f] \n", premios11, valor11)
	fmt.Printf("premios12 [%4d] valor +- [%10.2f]\n", premios12, valor12)
	fmt.Printf("premios13 [%4d] valor +- [%10.2f]\n", premios13, valor13)
	fmt.Printf("premios14 [%4d] valor +- [%10.2f]\n", premios14, valor14)
	fmt.Printf("premios15 [%4d] valor +- [%10.2f]\n", premios15, valor15)
	fmt.Printf("gastou +- [%10.2f]\nganhou +- [%10.2f]\n", gastou, premio)
	/*
		fmt.Printf("num 01  [%4d] ", number_01)
		fmt.Printf("num 02  [%4d] ", number_02)
		fmt.Printf("num 03  [%4d] ", number_03)
		fmt.Printf("num 04  [%4d] ", number_04)
		fmt.Printf("num 05  [%4d] \n", number_05)
		fmt.Printf("num 06  [%4d] ", number_06)
		fmt.Printf("num 07  [%4d] ", number_07)
		fmt.Printf("num 08  [%4d] ", number_08)
		fmt.Printf("num 09  [%4d] ", number_09)
		fmt.Printf("num 10  [%4d] \n", number_10)
		fmt.Printf("num 11  [%4d] ", number_11)
		fmt.Printf("num 12  [%4d] ", number_12)
		fmt.Printf("num 13  [%4d] ", number_13)
		fmt.Printf("num 14  [%4d] ", number_14)
		fmt.Printf("num 15  [%4d] \n", number_15)
		fmt.Printf("num 16  [%4d] ", number_16)
		fmt.Printf("num 17  [%4d] ", number_17)
		fmt.Printf("num 18  [%4d] ", number_18)
		fmt.Printf("num 19  [%4d] ", number_19)
		fmt.Printf("num 20  [%4d] \n", number_20)
		fmt.Printf("num 21  [%4d] ", number_21)
		fmt.Printf("num 22  [%4d] ", number_22)
		fmt.Printf("num 23  [%4d] ", number_23)
		fmt.Printf("num 24  [%4d] ", number_24)
		fmt.Printf("num 25  [%4d] \n", number_25)
	*/
	err = file.Close()
	check(err, "problem to close file")
}

func loadConcourseData(concourse string) *Response {
	requestURL := fmt.Sprintf("%s%s", "https://servicebus2.caixa.gov.br/portaldeloterias/api/lotofacil/", concourse)

	req, err := http.NewRequest(http.MethodGet, requestURL, nil)
	if err != nil {
		fmt.Printf("client: could not create request: %s\n", err)
		os.Exit(1)
	}
	req.Header.Set("Content-Type", "application/json, text/plain, */*")
	req.Header.Set("origin", "https://loterias.caixa.gov.br")
	req.Header.Set("accept", "application/json, text/plain, */*")
	req.Header.Set("sec-fetch-mode", "cors")
	req.Header.Set("sec-fetch-site", "same-site")
	req.Header.Set("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0")

	client := http.Client{
		Timeout: 30 * time.Second,
	}

	res, err := client.Do(req)
	if err != nil {
		fmt.Printf("client: error making http request: %s\n", err)
		os.Exit(1)
	}

	fmt.Print(res.StatusCode)

	if res.StatusCode != 200 {
		fmt.Printf("without response data")
		err = res.Body.Close()
		check(err, "problem to close response body")
		return nil
	}

	var data Response
	if err := json.NewDecoder(res.Body).Decode(&data); err != nil {
		fmt.Print(err)
	}
	err = res.Body.Close()
	check(err, "problem to close response body")

	return &data

}

func writeDataOnFile(data Response) {
	fmt.Print(data)

	filePath := "c:\\projects\\gojetbrain\\loto.txt"
	//f, err := os.Create(filePath)
	f, err := os.OpenFile(filePath, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	check(err, "Error to create file, or open file to changes")

	wroteBytes, err := f.WriteString(fmt.Sprintf("%v | %s \n", data.Numero, strings.Join(data.ListaDezenas, ", ")))
	check(err, "Error to write data on file")

	fmt.Printf("wrote %d bytes\n", wroteBytes)
	err = f.Sync()
	check(err, "Error to synchronize file")

	err = f.Close()
	check(err, "Error to close file")
}

func check(e error, message string) {
	if e != nil {
		fmt.Printf("%s | %v", message, e.Error())
		panic(e)
	}
}
